<?php
header('Content-Type: text/html; charset=utf-8');

session_start();

function __autoload($class){
    require_once($class.'.class.php');
}

if($_SESSION['Auth']){
    $base = Base::getInstance();
    $base->createTables();
    $file = new File($base->connection);

    if($_SERVER['REQUEST_METHOD'] == 'GET' || $_FILES['file']['error'] != 0){
    echo "<p>Привет " . $_SESSION['Email'] . "!</p>";
    echo "<p><a href='exit.php'>Сменить пользователя</a></p><hr>";
        if($file->existFile($_SESSION['UserId'])){
            $file->getAllFiles($_SESSION['UserId']);
            echo '<p><b>Files</b></p>';
            echo '<p><table border="1">';
            echo '<tr><th>File id</th><th>Url</th></tr>';
            foreach($file->values as $item){
                $url = 'http://' . $_SERVER['HTTP_HOST'] . stristr($_SERVER["PHP_SELF"], '/file.php', true) . '/files/' . $item['url'];
                echo '<tr><td>'. $item['fileId'] . '</td>';
                echo '<td><a href=' . $url . ' target="_blank">' . $url . '</a></td></tr>';
            }
            echo '</table></p>';
            echo '<hr>';
        }
    }

    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        if($_FILES['file']['error'] == 0){
            $tmpName = $_FILES['file']['tmp_name'];
            $tmpFileName = basename($tmpName);
            $tmpFileName = stristr($tmpFileName, '.tmp', true);

            $name = $_FILES['file']['name'];
            $pieces = explode('.', $name);
            $count = count($pieces);
            $type = $pieces[$count-1];

            $fileName = $tmpFileName . '.' . $type;

            $file->setFile($_SESSION['UserId'], $fileName);
            move_uploaded_file($tmpName, 'files/' . $fileName);

            header("location: " . $_SERVER["PHP_SELF"]);
            exit;
        }
        else{
            echo "Файл не выбран!";
        }
    }
}
else{
    header("location: index.php");
    exit;
}
?>

<html>
<head>
    <title></title>
</head>
<body>
    <form enctype="multipart/form-data" action="<?php $_SERVER["PHP_SELF"]?>" method="post">
        <p><b>Загрузить файл</b></p>
        <p>Выберите файл: <input type="file" name="file"></p>
        <p><input type="submit" name="submit" value="Отправить"></p>
    </form>
</body>
</html>