<?php
class Base{
    const SERVER = 'localhost';
    const LOGIN = 'root';
    const PASSWORD = '';

    public $connection;
    private static $_instance;

    public static function getInstance(){
        if(!(self::$_instance instanceOf self)){
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    private function __construct(){
        $conn = @mysqli_connect(self::SERVER, self::LOGIN, self::PASSWORD) or die("Don't connect with MySql");
        $sqlBase = "CREATE DATABASE Upload";
        mysqli_query($conn, $sqlBase);
        mysqli_close($conn);
        $this->connection = @mysqli_connect(self::SERVER, self::LOGIN, self::PASSWORD, 'Upload') or die("Don't connect with Upload");
    }

    public function createTables(){
        $sqlUsers = "SHOW TABLES LIKE 'Users'";
        if((mysqli_query($this->connection, $sqlUsers)->num_rows) == 0){
            $sqlCUsers = "CREATE TABLE Users (UserId INT(3) AUTO_INCREMENT PRIMARY KEY,
                                              Email VARCHAR(30),
                                              Password VARCHAR(40),
                                              Uid VARCHAR(40))";
            mysqli_query($this->connection, $sqlCUsers);
        }
        $sqlFiles = "SHOW TABLES LIKE 'Files'";
        if((mysqli_query($this->connection, $sqlFiles)->num_rows) == 0){
            $sqlCFiles = "CREATE TABLE Files (FileId INT(3) AUTO_INCREMENT PRIMARY KEY,
                                              UserId INT(3),
                                              Url VARCHAR(100))";
            mysqli_query($this->connection, $sqlCFiles);
        }
    }
}