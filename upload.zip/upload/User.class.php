<?php
class User{
    public $connection;
    public $values;

    public function __construct($connection){
        $this->connection = $connection;
    }

    public function existAnyUser(){
        $sqlExistAny = "SELECT COUNT(*) FROM Users";
        $resValues = mysqli_query($this->connection, $sqlExistAny);
        $item = mysqli_fetch_row($resValues);
        return $item[0];
    }

    public function existUser($email){
        $sqlExist = "SELECT COUNT(*) FROM Users WHERE Email = '$email'";
        $resValues = mysqli_query($this->connection, $sqlExist);
        $item = mysqli_fetch_row($resValues);
        return $item[0];
    }

    public function setUser($email, $password, $uid){
        $sqlSet = "INSERT INTO Users (Email, Password, Uid) VALUES ('$email', '$password', '$uid')";
        mysqli_query($this->connection, $sqlSet);
    }

    public function getUser($email){
        $sqlGet = "SELECT * FROM Users WHERE Email = '$email'";
        $resValues = mysqli_query($this->connection, $sqlGet);
        if($item = mysqli_fetch_assoc($resValues)){
            $this->values = array('userId'=>$item['UserId'],
                                  'email'=>$item['Email'],
                                  'password'=>$item['Password'],
                                  'uid'=>$item['Uid']);
        }
    }
}