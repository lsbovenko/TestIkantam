<?php
header('Content-Type: text/html; charset=utf-8');

session_start();

$data = array(0 => array('email' => 'qwe@mail.ru', 'password' => '11111111'),
              1 => array('email' => 'asd@mail.ru', 'password' => '22222222'),
              2 => array('email' => 'zxc@mail.ru', 'password' => '33333333'));

function __autoload($class){
    require_once($class.'.class.php');
}

$base = Base::getInstance();
$base->createTables();
$user = new User($base->connection);

if(!($user->existAnyUser())){
    foreach($data as $item)
        $user->setUser($item['email'], md5($item['password']), md5($item['email'] . $item['password']));
}

if(isset($_SESSION['Email']) && isset($_SESSION['Uid'])){
    if($user->existUser($_SESSION['Email'])){
        $user->getUser($_SESSION['Email']);
        if($user->values['uid'] == $_SESSION['Uid']){
            $_SESSION['UserId'] = $user->values['userId'];
            $_SESSION['Auth'] = true;
            header("location: file.php");
            exit;
        }
        else
            echo "Не корректный Uid пользователя!";
    }
    else
        echo "Пользователя с е-мейлом " . $_SESSION['Email'] . " не существует!";
}

if($_SERVER["REQUEST_METHOD"] == "POST"){
    if($_POST["email"] != null){
        if(preg_match("/^[a-z0-9]+[\.a-z0-9_-]*@[a-z0-9_-]+(\.[a-z0-9_-]+)*\.[a-z]{2,6}$/i", trim($_POST["email"]))){
            if(strlen(trim($_POST["password"])) >= 8){
                $email = trim(strip_tags($_POST["email"]));
                $password = md5(trim(strip_tags($_POST["password"])));
                if($user->existUser($email)){
                    $user->getUser($email);
                    if($user->values['password'] == $password){
                        $_SESSION['Email'] = $email;
                        $_SESSION['Uid'] = $user->values['uid'];
                        header("location: " . $_SERVER["PHP_SELF"]);
                        exit;
                    }
                    else
                        echo "Не верный пароль!";
                }
                else
                    echo "Не верный e-mail!";
            }
            else
                echo "Пароль должен быть не менее 8 символов!";
        }
        else
            echo "E-mail не валидный!";
    }
    else
        echo "E-mail не может быть пустым!";
}
?>

<html>
<head>
    <title></title>
</head>
<body>
    <form action="<?php $_SERVER["PHP_SELF"]?>" method="post">
        <p><b>Введите e-mail и пароль</b></p>
        <p><input type="text" name="email" value=""> E-mail</p>
        <p><input type="password" name="password" value=""> Пароль</p>
        <p><input type="submit" value="Войти"></p>
    </form>
</body>
</html>