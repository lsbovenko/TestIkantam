<?php
class File{
    public $connection;
    public $values;

    public function __construct($connection){
        $this->connection = $connection;
    }

    public function existFile($userId){
        $sqlExist = "SELECT COUNT(*) FROM Files WHERE UserId = $userId";
        $resValues = mysqli_query($this->connection, $sqlExist);
        $item = mysqli_fetch_row($resValues);
        return $item[0];
    }

    public function setFile($userId, $url){
        $sqlSet = "INSERT INTO Files (UserId, Url) VALUES ($userId, '$url')";
        mysqli_query($this->connection, $sqlSet);
    }

    public function getAllFiles($userId){
        $sqlGetAll = "SELECT * FROM Files WHERE UserId = $userId ORDER BY FileId DESC";
        $resValues = mysqli_query($this->connection, $sqlGetAll);
        while($item = mysqli_fetch_assoc($resValues)){
            $this->values[] = array('fileId'=>$item['FileId'],
                                    'userId'=>$item['UserId'],
                                    'url'=>$item['Url']);
        }
    }
}